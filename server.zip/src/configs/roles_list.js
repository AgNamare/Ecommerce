export const ROLES_LIST = {
  Admin: 5150,
  SuperAdmin: 4178,
};
